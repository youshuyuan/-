from snownlp import SnowNLP
import os
import pandas as pd 

from pyecharts.charts import Map
from pyecharts import options as opts


#absPath = os.path.realpath(__file__)
dirPro = os.getcwd()
csv_path = dirPro + os.sep + 'weibo_spider' + os.sep + 'data'+os.sep+'data_deal_dinglei.csv'
data = pd.read_csv(csv_path,encoding='utf-8')

positives= {}

data_pro = data['评论地点']
data_text = data['评论内容']

pro = set(data_pro)

for i in pro:
    sentiment_list = []
    for text,prov in zip(data_text,data_pro):
        if i == prov:
            s = SnowNLP(text)
            sentiment_list.append(s.sentiments)
    
            #统计平均情感
            positive_number = sum(sentiment_list)
            positive = positive_number /len(sentiment_list) *100

            #按省保存数据
            positives[i] = int(positive)

#print(positives)
keys = list(positives.keys())
values =list(positives.values())
data = [[n, v] for n, v in positives.items()]
print(data)

# map = Map('少儿编程纳入学业水平考试')
# map.add("积极情感", keys, values, visual_range=[0, 100], maptype='china', is_visualmap=True, is_label_show=True, visual_text_color='#000')
# map.render(path="少儿编程纳入学业水平考试.html")      


# ggeo=(
#     Map()
#     .add('评论人数',data,maptype='china')

#      .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
#     .set_global_opts(
# #             visualmap_opts=opts.VisualMapOpts(max_=600000),
#             title_opts=opts.TitleOpts(title='少儿编程纳入学业水平考试'))
# )

# ggeo.render('map.html')

    

