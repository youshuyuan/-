import pymysql
import os
from wordcloud import WordCloud
import PIL.Image as Image
import numpy as np 
import jieba
import matplotlib.pyplot as plt 

def read(sql):
    #进行数据库连接
    conn = pymysql.connect(host='139.196.4.130', port=3306, 
                    user='root', passwd='root', 
                    db='shixun', charset='utf8mb4', connect_timeout=1000)

    #获取游标
    cursor  = conn.cursor()
    cursor.execute(sql)
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return results

def tupleToTxt(data,txt_Path):
    with open(txt_path,'w',encoding='utf-8') as fp:
        for i in data:
            fp.write(' '.join(str(s) for s in i) + '\n')


# 分词
def trans_CN(text):
	# 接收分词的字符串
    word_list = jieba.cut(text)
    # 分词后在单独个体之间加上空格
    result = " ".join(word_list)
    return result

def ciyun(filename,dirPath):
    with open(filename,'r',encoding='utf-8') as fr:
        text = fr.read()
        text_fenci = trans_CN(text)
        #从data中获取elephant.jpg文件并转换为numpy的array类型
        picPath = os.path.join(dirPath,"elephant.jpg")
        elephant = np.array(Image.open(picPath))
        #设置词云
        wc = WordCloud(font_path='./fonts/simhei.ttf',background_color="white",width=1000,height=800,max_font_size=50,scale=10,mask=elephant)
        #生成词云
        wc.generate(text_fenci)
        #直接将词云保存为图片
        wordCloudRes = os.path.join(dirPath,"wordCloud.png")
        wc.to_file(wordCloudRes)

        #使用matplotlib热图显示词云
        plt.figure()
        #使用热图显示
        plt.imshow(wc,interpolation="bilinear")
        plt.axis("off")  #关闭坐标
        wordCloudRes2 = os.path.join(dirPath,"wordCloud2.png")
        plt.savefig(wordCloudRes2)
        plt.show()

            
if __name__ == "__main__":
    res = read('select title from hot')
    #文件路径
    absPath = os.path.realpath(__file__)
    dirname = os.path.dirname(absPath)
    
    txt_path = dirname + os.sep + "wordCloud.txt"
    #存入txt
    tupleToTxt(res,txt_path)
    #词云
    ciyun(txt_path,dirname)
    
    
    
    

