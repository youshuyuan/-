'''
根据微博id获取评论
'''



from weibopy import WeiboOauth2,WeiboClient
import webbrowser
import csv
import os

absPath = os.path.realpath(__file__)
dirname = os.path.dirname(absPath)
csv_path = dirname + os.sep + "comment_a.csv"

APP_KEY = '1439451658'
APP_SECRET = 'ac5e9d832006ba2e458ea08c62f321dc'
CALLBACK_URL = 'https://api.weibo.com/oauth2/default.html'
#回调授权页面，用户完成授权后返回的页面
client= WeiboOauth2(client_id=APP_KEY, client_secret=APP_SECRET, redirect_url=CALLBACK_URL)
#得到授权页面的url，并打开这个url
url = client.authorize_url
webbrowser.open_new(url)
code = input("please input code : ")

r = client.auth_access(code)
b = WeiboClient(r['access_token'])


#创建文件对象
f = open(csv_path,'w',encoding='utf-8')

#基于文件对象创建csv写入对象
csv_writer = csv.writer(f)

#构建列表头
csv_writer.writerow(['评论者','评论时间','评论地点','评论内容'])

# # 获取评论信息
for i in range(1,11):
  # suffix 指定 API 的名称，parmas 是参数，在文档中有详细描述
  result = b.get(suffix='comments/show.json', params={'id': 4505953183511676 , 'count': 200 , 'page': i}) 
  #4505685952002627：她向世界说出真实的香港  4505878566966191：中餐厅   
  #4506073249682720：王凯我还是想做官家   4506306038403944:教师工资不低于公务员年底须完成
  comments = result['comments']
  for j in comments:
      text = j["text"]
      id = j["id"]
      created_at = j["created_at"]
      location = j['user']['location']
      name = j['user']['name']
      #写入csv文件内容
      csv_writer.writerow([name,created_at,location,text])

#关闭文件
f.close()

 

      
     
      
      #print('page{}:'.format(i),name,text,id,created_at,location)