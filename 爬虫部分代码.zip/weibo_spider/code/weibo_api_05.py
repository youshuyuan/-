# '''
# 根据微博id获取评论
# '''



# from weibopy import WeiboOauth2,WeiboClient
# import webbrowser

# from DecryptLogin import login
# lg = login.Login()
# #infos_return, session = lg.zhihu(username='1548658584@qq.com', password='wz1548658584')
# infos_return, session = lg.weibo(username='2915136814@qq.com', password='wz1548658584..',mode='mobile')



# APP_KEY = '427087851'
# APP_SECRET = 'ba930d985d65ad860c68799638e7542e'
# CALLBACK_URL = 'https://api.weibo.com/oauth2/default.html'
# #回调授权页面，用户完成授权后返回的页面
# client= WeiboOauth2(client_id=APP_KEY, client_secret=APP_SECRET, redirect_url=CALLBACK_URL)
# #得到授权页面的url，并打开这个url
# url = client.authorize_url
# webbrowser.open_new(url)
# print(url)
# code = input("please input code : ")

# r = client.auth_access(code)
# b = WeiboClient(r['access_token'])


# # # 获取评论信息
# for i in range(1,2):
#   # suffix 指定 API 的名称，parmas 是参数，在文档中有详细描述
#   result = b.get(suffix='comments/show.json', params={'id': 4505953183511676 , 'count': 200 , 'page': i}) 
  
#   comments = result['comments']
#   for j in comments:
#       text = j["text"]
#       id = j["id"]
#       created_at = j["created_at"]
#       location = j['user']['location']
#       name = j['user']['name']

#       print('page{}:'.format(i),name,text,id,created_at,location)