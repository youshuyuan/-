'''
1 根据微博id获取评论
2 代码参数化
3 根据获得的省份代号 获取省份名称
'''


from weibopy import WeiboOauth2,WeiboClient
import webbrowser
import csv
import os
import re

APP_KEY = '427087851'
APP_SECRET = 'ba930d985d65ad860c68799638e7542e'
CALLBACK_URL = 'https://api.weibo.com/oauth2/default.html'
#回调授权页面，用户完成授权后返回的页面
client= WeiboOauth2(client_id=APP_KEY, client_secret=APP_SECRET, redirect_url=CALLBACK_URL)
#得到授权页面的url，并打开这个url
url = client.authorize_url
webbrowser.open_new(url)
code = input("please input code : ")

r = client.auth_access(code)
b = WeiboClient(r['access_token'])

# absPath = os.path.realpath(__file__)
# dirname = os.path.dirname(absPath)
proname = os.getcwd()
dirname = proname + os.sep + 'weibo_spider' + os.sep + 'data'

wid = input("请输入你要爬取的微博id：")
csv_path = dirname + os.sep + 'comment_' + str(wid) + '.csv'

#创建文件对象
f = open(csv_path,'w',encoding='utf-8')

#基于文件对象创建csv写入对象
csv_writer = csv.writer(f)

#构建列表头
csv_writer.writerow(['评论者','评论时间','评论地点','评论内容'])



for i in range(1,11):
  
  result = b.get(suffix='comments/show.json', params={'id': wid , 'count': 200 , 'page': i})
  provinces = {}
  results = b.get(suffix='common/get_province.json', params={'country': '001'})
  for prov in results:
      for code, name in prov.items():
          provinces[code] = name
  #print(provinces) 

  comments = result['comments']
  for j in comments:
      

      text = j["text"]
      # 替换为空字符串
      text1 = re.sub('回复.*?:', '', str(text))
      created_at = j["created_at"]
      location = j['user']['location']
      name = j['user']['name']
      province_code = j['user']['province']
      province_code_all = '0010'+str(province_code)
      if province_code_all  in provinces:
          province_name = provinces[province_code_all]
      else:
          province_name='其他'
      #写入csv文件内容
      csv_writer.writerow([name,created_at,province_name,text1])
          
      
      #print(province_name,text,name,location)
#关闭文件
f.close()
      

