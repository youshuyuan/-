import datetime
import pymysql
import re

'''
%y 两位数的年份表示（00-99）
%Y 四位数的年份表示（000-9999）
%m 月份（01-12）
%d 月内中的一天（0-31）
%H 24小时制小时数（0-23）
%I 12小时制小时数（01-12）
%M 分钟数（00=59）
%S 秒（00-59）
%a 本地简化星期名称
%A 本地完整星期名称
%b 本地简化的月份名称
%B 本地完整的月份名称
%c 本地相应的日期表示和时间表示
%j 年内的一天（001-366）
%p 本地A.M.或P.M.的等价符
%U 一年中的星期数（00-53）星期天为星期的开始
%w 星期（0-6），星期天为星期的开始
%W 一年中的星期数（00-53）星期一为星期的开始
%x 本地相应的日期表示
%X 本地相应的时间表示
%z 当前时区的名称
%% %号本身 、


'''
#连接数据库
conn = pymysql.connect(host='112.124.15.73', port=3306, 
            user='user1', passwd='user1', 
            db='weibo', charset='utf8mb4', connect_timeout=1000,autocommit=True)
cursor = conn.cursor()


def dataCount(*res):
    total=[]
    for i in res:
        for j in i:
            #print(j)
            str_j = ' '.join(j)
            time_format=datetime.datetime.strptime(str_j,'%a %b %d %H:%M:%S %z %Y')
            time_format=str(time_format)
            times=time_format[5:13]
            #print(times)
            total.append(times)
    
    
    
    dict_pro = {}
    for i in total:
        if i not in dict_pro:
            dict_pro[i] =0
        dict_pro[i] += 1
    return dict_pro

#元组转成列表
def tupleToList(*a):
    resList=[]
    for i in a:
        for j in i:
            str_j =''.join('%s' %id for id in j)
            resList.append(str_j)
    return resList

#title获得ids
def titleGetIds(title):
    selectsql = "select id from wb_hot where title='%s'" %(title)
    cursor.execute(selectsql)
    res = cursor.fetchall()
    return res

#根据微博id获得评论时间
def idGetTime(id):
    selecttime = "select time from wb_comment where wb_id='%s'" %(id)
    cursor.execute(selecttime)
    res = cursor.fetchall()
    return res

#根据微博类别获得微博title
def labelGetTitles(label):
    selectTitle = "select title from wb_title where label='%s'" %(label)
    cursor.execute(selectTitle)
    res=cursor.fetchall()
    return res

def setSort(a=set()):
    c = []
    for i in a:
        c.append(i)
    c.sort()
    return c

if __name__ == "__main__":
    labels = ['时政','娱乐']
    a = ['00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23']

    for label in labels:
        titles = tupleToList(labelGetTitles(label))
        #print(titles)
        for title in titles:
            timestotal={}
            ids=titleGetIds(title)
            str_ids=tupleToList(ids)
            newdic ={}
            #print(title,str_ids)
            for id in str_ids:
                times = idGetTime(id)
                #print(times)
                nums = dataCount(times)
                #print(nums)
                for k,v in nums.items():
                    if k not in timestotal.keys():
                        timestotal[k] =0
                    timestotal[k] += v
            #print('{}时间统计的结果为{}'.format(title,timestotal))
            dates = set()
            for k,v in timestotal.items():
                month = k[0:3]
                date = k[3:5]
                dates.add(date)
            #print(dates)
            #时间补全
            dates=setSort(dates)
            for date in dates:
                for i in a:
                    for k,v in timestotal.items():
                        hours = k[6:8]
                        riqi = '06-' + date +' '
                        newkey =riqi + str(i)
                        if newkey != k:
                            newdic[newkey]=0
                        else:
                            newdic[newkey]=v
                            break
            print(title,newdic)

            for k,v in newdic.items():
                #print(title,k,v)
                int_v = int(v)

                selectsql = "select count from wb_timeCount where title='%s' and time='%s'" %(title,k)
                updatesql = "update wb_timeCount Set count = '%s' where title='%s' and time='%s'"%(int_v,title,k)
                cursor.execute(selectsql)
                res=cursor.fetchall()
                if len(res) == 0:
                    insertsql = 'Replace INTO `wb_timeCount`(title,time,count) VALUES("%s","%s","%s") ' %(title,k,int_v)
                    cursor.execute(insertsql)
                else:
                    cursor.execute(updatesql)
            print('success')
            
            


cursor.close()
conn.close()









        



    
