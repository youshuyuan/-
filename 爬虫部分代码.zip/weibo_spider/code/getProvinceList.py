from weibopy import WeiboOauth2,WeiboClient
import webbrowser

def getList():
    APP_KEY = '427087851'
    APP_SECRET = 'ba930d985d65ad860c68799638e7542e'
    CALLBACK_URL = 'https://api.weibo.com/oauth2/default.html'
    #回调授权页面，用户完成授权后返回的页面
    client= WeiboOauth2(client_id=APP_KEY, client_secret=APP_SECRET, redirect_url=CALLBACK_URL)
    #得到授权页面的url，并打开这个url
    url = client.authorize_url
    webbrowser.open_new(url)
    code = input("please input code : ")

    r = client.auth_access(code)
    b = WeiboClient(r['access_token'])
    provinces = {}
    results = b.get(suffix='common/get_province.json', params={'country': '001'})
    for prov in results:
        for code, name in prov.items():
            provinces[code] = name
    print(provinces) 


if __name__ == "__main__":
    getList()
    




