'''

微博热点抓取

'''

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

import time



#引入数据库模块
import pymysql
#进行mysql连接操作
conn = pymysql.connect(host='139.196.4.130', port=3306, 
                user='root', passwd='root', 
                db='shixun', charset='utf8mb4', connect_timeout=1000)

#获取游标
cursor = conn.cursor()

options = webdriver.FirefoxOptions()
options.add_argument('--headless')

driver = webdriver.Firefox(executable_path= 'C:\\dev\\webdriver\\geckodriver.exe',options=options)
url = "https://s.weibo.com/top/summary/"
driver.get(url)
time.sleep(2)
title = driver.find_elements_by_css_selector(" td.td-02>a")
num = driver.find_elements_by_css_selector("td.td-02>span")
user = []
del title[0]



localtime = time.asctime( time.localtime(time.time()) )
for i,j in zip(title,num):
    
    title_txt = i.text
    redu = j.text

    insertsql = ("INSERT INTO hot(title,hot,time)" "VALUES(%s,%s,%s)")
    data = (title_txt,redu,localtime)
    cursor.execute(insertsql, data)
    conn.commit()
    
    
    print(title_txt,redu)


driver.close()
conn.close()

    
     
