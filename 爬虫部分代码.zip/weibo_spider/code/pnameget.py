from weibopy import WeiboOauth2,WeiboClient
import webbrowser
import pymysql



provinces ={'001011': '北京', '001012': '天津', '001013': '河北', '001014': '山西', '001015': '内蒙古', '001021': '辽宁', '001022': '吉林', '001023': '黑龙江', '001031': '上海', '001032': 
'江苏', '001033': '浙江', '001034': '安徽', '001035': '福建', '001036': '江西', '001037': '山东', '001041': '河南', '001042': '湖北', '001043': '湖南', '001044': '广东', '001045': '广西', '001046': '海南', '001050': '重庆', '001051': '四川', '001052': '贵州', '001053': '云南', '001054': '西藏', '001061': '陕西', '001062': '甘肃', '001063': '青海', '001064': '宁夏', '001065': '新疆', '001071': '台湾', '001081': '香港', '001082': '澳门'}

#连接数据库
conn = pymysql.connect(host='112.124.15.73', port=3306, 
            user='user1', passwd='user1', 
            db='weibo', charset='utf8mb4', connect_timeout=1000,autocommit=True)
cursor = conn.cursor()



def getname(pid):
    province_code_all = '0010'+str(pid)
    if province_code_all  in provinces:
        province_name = provinces[province_code_all]
    else:
        province_name='其他'
    return province_name

if __name__ == "__main__":
    selectsql = "select province from wb_comment"
    cursor.execute(selectsql)
    pids = cursor.fetchall()
    #print(pids)
    for i in pids:
        for pid in i:
            pname = getname(pid)
            updatesql = "update wb_comment Set pname = '%s' where province='%s' "%(pname,pid)
            cursor.execute(updatesql)


cursor.close()
conn.close()
    





# def getProvince():
#     APP_KEY = '427087851'
#     APP_SECRET = 'ba930d985d65ad860c68799638e7542e'
#     CALLBACK_URL = 'https://api.weibo.com/oauth2/default.html'
#     #回调授权页面，用户完成授权后返回的页面
#     client= WeiboOauth2(client_id=APP_KEY, client_secret=APP_SECRET, redirect_url=CALLBACK_URL)
#     #得到授权页面的url，并打开这个url
#     url = client.authorize_url
#     webbrowser.open_new(url)
#     code = input("please input code : ")

#     r = client.auth_access(code)
#     b = WeiboClient(r['access_token'])
#     provinces = {}
#     results = b.get(suffix='common/get_province.json', params={'country': '001'})
#     for prov in results:
#         for code, name in prov.items():
#             provinces[code] = name
#     print(provinces) 