import pymysql

#连接数据库
conn = pymysql.connect(host='112.124.15.73', port=3306, 
            user='user1', passwd='user1', 
            db='weibo', charset='utf8mb4', connect_timeout=1000,autocommit=True)

cursor = conn.cursor()
def findByLabel(label):
    sql = "select title from wb_content where label='%s'" %(label)
    cursor.execute(sql)
    res= cursor.fetchall()
    titles = set()
    for tupleTitle in res:
        
        str_title=''.join(tupleTitle)
        titles.add(str_title)
    print(titles)
    for onetitle in titles:
        selectsql = "select label from wb_title where title='%s'" %(onetitle)
        cursor.execute(selectsql)
        res2 = cursor.fetchall()
        if len(res2)==0:
            insertsql = 'Replace INTO `wb_title`(title,label) VALUES("%s","%s") ' %(onetitle,label)
            cursor.execute(insertsql)
    

if __name__ == "__main__":
    labels = ['娱乐','时政','体育']
    for label in labels:
        #print(label)
        findByLabel(label)
    

cursor.close()
conn.close()