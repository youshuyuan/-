'''

对批量获得的微博进行分类

'''

import os
import numpy as np 
import pandas as pd 
import csv 

absPath = os.path.realpath(__file__)
dirname = os.path.dirname(absPath)
#csv_read_path = dirname + os.sep + "text_entertainment.csv"
#csv_read_path = dirname + os.sep + "text_shizheng.csv"
csv_read_path = dirname + os.sep + "text_sports.csv"
csv_save_path = dirname + os.sep + "data_deal_label.csv"

data = pd.read_csv(csv_read_path)

#创建文件对象
f = open(csv_save_path,'a+',encoding='utf-8')

#基于文件对象创建csv写入对象
csv_writer = csv.writer(f)

#构建列表头
#csv_writer.writerow(['微博内容','微博类别'])

data_text = data['微博内容']

for i in data_text:
    #写入csv文件内容
    csv_writer.writerow([i,'体育'])

f.close()
    

