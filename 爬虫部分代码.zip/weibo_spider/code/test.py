import pymysql
# import datetime

#连接数据库
conn = pymysql.connect(host='112.124.15.73', port=3306, 
            user='user1', passwd='user1', 
            db='weibo', charset='utf8mb4', connect_timeout=1000,autocommit=True)
cursor = conn.cursor()

selectsql = "select time,count from wb_timeCount where title='黑人死亡拍摄者被质疑见死不救' "
cursor.execute(selectsql)
res= cursor.fetchall()
print(res)




# selecttime = "select time from wb_comment where wb_id='4512167069810572'" 
# cursor.execute(selecttime)
# res = cursor.fetchall()
# total=[]
# for i in res:
#     for j in i:
#         #print(j)
#         str_j = ' '.join(j)
#         time_format=datetime.datetime.strptime(j,'%a %b %d %H:%M:%S %z %Y')
#         time_format=str(time_format)
#         times=time_format[5:13]
#         #print(times)
#         total.append(times)
#         print(times)
# #print(total)
# cursor.close()
# conn.close()


# a = ['aa','bb','cc','dd','ee','ff','gg']
# b = {'cc':56,'dd':88,'ff':99}
# dic1= {}
# for k,v in b.items():
#     dic1[k]=v
# print(dic1)
# newdic ={}
# for i in a:
#     for k in b.keys():
#         if i != k:
#             newdic[i]=0
#         else:
#             newdic[i]=dic1[k]
#             break
       
# print(newdic)