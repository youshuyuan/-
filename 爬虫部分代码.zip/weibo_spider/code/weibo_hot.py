'''

微博热点抓取

'''


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import os
import time
import csv 

absPath = os.path.realpath(__file__)
dirname = os.path.dirname(absPath)
csv_path = dirname + os.sep + "hot.csv"

driver = webdriver.Chrome()
url = "https://s.weibo.com/top/summary/"
driver.get(url)
time.sleep(2)
title = driver.find_elements_by_css_selector(" td.td-02>a")
num = driver.find_elements_by_css_selector("td.td-02>span")
user = []
del title[0]

#创建文件对象
f = open(csv_path,'a+',encoding='utf-8')

#基于文件对象创建csv写入对象
csv_writer = csv.writer(f)

#构建列表头
csv_writer.writerow(['排名','标题','热度','时间'])
count =0
localtime = time.asctime( time.localtime(time.time()) )
for i,j in zip(title,num):
    count += 1
    title_txt = i.text
    redu = j.text
    
    #写入csv文件内容
    csv_writer.writerow([count,title_txt,redu,localtime])
    
    #print(title_txt,redu)
#关闭文件
f.close()
driver.close()


    
     
