'''
数据处理

1 获取评论各省份人数
2 去除“回复”等字眼



'''


import os
import pandas as pd 
import csv
import re

absPath = os.path.realpath(__file__)
dirname = os.path.dirname(absPath)
csv_path = dirname + os.sep + "comment_4512185784673118.csv"
csv_path_deal =dirname + os.sep + "data_deal_caoyuan.csv"

#csv_path_province = dirname +os.sep + "data_province_mengwanzhou.csv"

data = pd.read_csv(csv_path)


#去除评论中“回复”
#创建文件对象
f = open(csv_path_deal,'w',encoding='utf-8')

#基于文件对象创建csv写入
csv_writer = csv.writer(f)

#构建列表头
csv_writer.writerow(['评论者','评论时间','评论地点','评论内容'])


data_name = data['评论者']
data_time = data['评论时间']
data_address =data['评论地点']
data_text =data['评论内容']

for a,b,c,d in zip(data_name,data_time,data_address,data_text):
    
    # 替换为空字符串
    text = re.sub('回复.*?:', '', str(d))
    csv_writer.writerow([a,b,c,text])

#关闭文件
f.close()


# #计算某一省份人数
# #创建文件对象
# f = open(csv_path_province,'w',encoding='utf-8')

# #基于文件对象创建csv写入
# csv_writer = csv.writer(f)

# #构建列表头
# csv_writer.writerow(['province','count'])

# data_province = data['评论地点']
# dict_pro = {}
# count =0
# for i in data_province:
#     if i not in dict_pro:
#         dict_pro[i] =0
#     dict_pro[i] += 1

# for key,value in dict_pro.items():
#     csv_writer.writerow([key,value])
    


# f.close()

    
# print(data_province)
# print(dict_pro)
    
    