import pymysql
conn = pymysql.connect(host='112.124.15.73', port=3306, 
                user='user1', passwd='user1', 
                db='weibo', charset='utf8mb4', connect_timeout=1000,autocommit=True)

cursor = conn.cursor()

def sql_list(label):
    dict_pro={}
    data = []
    selectsql ="select pname,count from wb_locationCount_all where wbclass='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchall()
    for i in res:
        #print(res)
        tupleTolist = list(i)
        dict_pro[tupleTolist[0]] = int(tupleTolist[1])
    data = [[n, v] for n, v in dict_pro.items()]
    
    return data


if __name__ == "__main__":
    print(sql_list('时政'))
cursor.close()
conn.close()