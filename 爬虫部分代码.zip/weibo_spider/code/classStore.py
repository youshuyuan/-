import pymysql

conn = pymysql.connect(host='139.196.4.130', port=3306, 
                user='root', passwd='root', 
                db='shixun', charset='utf8mb4', connect_timeout=1000,autocommit=True)
cursor = conn.cursor()

#获取某一label的所有微博id
def idsOfLabel(label):
    sql = "select id from wb_hot where title =  '%s'" % label
    cursor.execute(sql)

    results = cursor.fetchall()
    ids = []
    for i in results:
        str_j = ''.join(str(i))
        #print(str_j)
        wid= str_j[2:3]
        #print(wid)
        #wid= str_j[1:17]
        ids.append(wid)
    return ids
    

#将相同种类的微博合并到一起
def classMerge(*ids):
    for i in ids:
        for j in i:
            #print(j)
            tablename = 'wb_' + str(j)
            sql = 'select name from %s'  % tablename
            cursor.execute(sql)
            res = cursor.fetchall()
            #print(res)
            for k in res:
                str_k = ''.join(k)
                #print(str_k)
                tablename = 'wb_4'
                sql2 = "INSERT INTO {}(title,name) VALUES ('{}','{}')".format(tablename,'1',str_k)
                sql2 = 'INSERT INTO `wb_tos`(name) VALUES("%s") ' %(str_k) 
                print(2)
                cursor.execute(sql2)


if __name__ == "__main__":
    label = 'wo'
    res=idsOfLabel(label)
    #print(res)
    classMerge(res)
    

   
cursor.close()
conn.close()