import pymysql

#连接数据库
# conn = pymysql.connect(host='112.124.15.73', port=3306, 
#             user='user1', passwd='user1', 
#             db='weibo', charset='utf8mb4', connect_timeout=1000)

conn = pymysql.connect(host='139.196.4.130', port=3306, 
                user='root', passwd='root', 
                db='shixun', charset='utf8mb4', connect_timeout=1000,autocommit=True)

cursor = conn.cursor()
#获取元组中省份
def getprovince(*res):
    provinces = []
    for i in res:
        for j in i:
            str_j = ''.join(j)
            provinces.append(str_j)
    return provinces

def addressCou(a):
    for i in a:
        sql = "select province from comment where cla='%s'" %i
        cursor.execute(sql)
        res = cursor.fetchall()
        str_res = getprovince(res)

        dict_pro = {}
        for pro in str_res:
            if pro not in dict_pro:
                dict_pro[pro] =0
            dict_pro[pro] += 1


        for key,value in dict_pro.items():
            selectsql = "select count from addressCount where province='%s' and label='%s'" %(key,i)
            updatesql = "update addressCount Set count = '%s' where province='%s' and label='%s'"%(value,key,i)
            cursor.execute(selectsql)
            res=cursor.fetchall()
            if len(res) == 0:
                insertsql = 'Replace INTO `addressCount`(province,count,label) VALUES("%s","%s","%s") ' %(key,value,i)
                cursor.execute(insertsql)
            else:
                cursor.execute(updatesql)

        print(str_res)
        




if __name__ == "__main__":
    a = ['时政','娱乐']
    addressCou(a)
    


cursor.close()
conn.close()