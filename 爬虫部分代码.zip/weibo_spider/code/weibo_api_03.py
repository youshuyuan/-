'''
批量爬取微博

'''
from weibopy import WeiboOauth2,WeiboClient
import webbrowser
import csv
import os

absPath = os.path.realpath(__file__)
dirname = os.path.dirname(absPath)
csv_path = dirname + os.sep + "text_0604.csv"


APP_KEY = '427087851'
APP_SECRET = 'ba930d985d65ad860c68799638e7542e'
CALLBACK_URL = 'https://api.weibo.com/oauth2/default.html'
#回调授权页面，用户完成授权后返回的页面
client= WeiboOauth2(client_id=APP_KEY, client_secret=APP_SECRET, redirect_url=CALLBACK_URL)
#得到授权页面的url，并打开这个url
url = client.authorize_url
webbrowser.open_new(url)
code = input("please input code : ")
r = client.auth_access(code)
b = WeiboClient(r['access_token'])

# #创建文件对象
f = open(csv_path,'w',encoding='utf-8')

#创建csv写入对象
csv_writer = csv.writer(f)

#创建列表头
csv_writer.writerow(['用户昵称','微博id','微博内容'])


for i in range(1,11):
  
  result = b.get(suffix='statuses/home_timeline.json', params={'count': 10 , 'page': i,'feature':1})

  contents = result['statuses']
  for j in contents:
      #获取微博id
      wid = j['id']
      #获取文本内容
      text = j["text"]
      #获取用户昵称
      name = j['user']['name']
      csv_writer.writerow([name,wid,text])

f.close()
                

      

     
     