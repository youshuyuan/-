'''
按类别统计地点
'''

import pymysql
import re

#连接数据库
conn = pymysql.connect(host='112.124.15.73', port=3306, 
            user='user1', passwd='user1', 
            db='weibo', charset='utf8mb4', connect_timeout=1000,autocommit=True)
cursor = conn.cursor()


#元组转成列表
def tupleToList(*a):
    resList=[]
    for i in a:
        for j in i:
            str_j =''.join('%s' %id for id in j)
            resList.append(str_j)
    return resList

#label获得ids
def labelGetIds(label):
    selectsql = "select id from wb_hot where label='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchall()
    return res
#通过id获得省份名称
def idGetPname(id):
    selectPname = "select pname from wb_comment where wb_id='%s'" %(id)
    cursor.execute(selectPname)
    res = cursor.fetchall()
    return res

#计算列表中元素个数
def locCount(a=list()):
    dict_pro={}
    for i in a:
        if i not in dict_pro:
            dict_pro[i]=0
        dict_pro[i]+=1
    return dict_pro

if __name__ == "__main__":
    labels = ['时政','娱乐','体育']
    for label in labels:
        ids=labelGetIds(label)
        str_ids=tupleToList(ids)
        totalLoc={}
        for id in str_ids:
            pnames = idGetPname(id)
            str_pnames = tupleToList(pnames)
            idCount = locCount(str_pnames)
            #print(id,idCount)
            for k,v in idCount.items():

                if k not in totalLoc.keys():
                    totalLoc[k] =0
                totalLoc[k] += v
        print(label,totalLoc)
          
        
        # for k,v in totalLoc.items():
        #     #print(k,v)
        #     int_v = int(v)
        #     selectsql = "select count from wb_locationCount_all where wbclass='%s' and pname='%s'" %(label,k)
        #     updatesql = "update wb_locationCount_all Set count = '%s' where wbclass='%s' and pname='%s'"%(int_v,label,k)
        #     cursor.execute(selectsql)
        #     res=cursor.fetchall()
        #     if len(res) == 0:
        #         insertsql = 'Replace INTO `wb_locationCount_all`(wbclass,pname,count) VALUES("%s","%s","%s") ' %(label,k,int_v)
        #         cursor.execute(insertsql)
        #     else:
        #         cursor.execute(updatesql)

  

cursor.close()
conn.close()








        



    
