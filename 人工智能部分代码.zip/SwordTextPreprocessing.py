#!/usr/bin/env python
# coding: utf-8

import jieba

def text_compress(text, max_length = 3, max = True):
    '''
        文本压缩，去除重复部分
        ===============
        arguments:
            text: 要处理的文本字符串
            max_length = 3: 要去除的重复词的最大长度，默认为文本长度的一半（受参数 max 控制）
            max = True: 使 max_length = int(len(text) / 2) 。若要自定义 max_length ，设置 max = False 
    '''
    if max:
        max_length = int(len(text) / 2)
    for length in range(1, max_length + 1):
        for i in range(len(text)):
            if text[i: i + length] == text[i + length: i + 2 * length]:
                j = i + length
                while text[j: j + length] == text[j + length: j + 2 * length] and j < len(text):
                    j += length
                text = text[: i] + text[j:]
    return text

def text_compress_save2(text, max_length = 3, max = True):
    '''
        文本压缩，去除重复部分，保留叠词（ XX 型）
        ===============
        arguments:
            text: 要处理的文本字符串
            max_length = 3: 要去除的重复词的最大长度，默认为文本长度的一半（受参数 max 控制）
            max = True: 使 max_length = int(len(text) / 2) 。若要自定义 max_length ，设置 max = False 
    '''
    if max:
        max_length = int(len(text) / 2)
    for length in range(1, max_length + 1):
        for i in range(len(text)):
            if text[i: i + length] == text[i + length: i + 2 * length]:
                j = i + length
                while text[j: j + length] == text[j + length: j + 2 * length] and j < len(text):
                    j += length
                if(length == 1):
                    #对长度为1的重复词单独处理（保留叠词）
                    text = text[: i] + text[j - 1:]
                else:
                    text = text[: i] + text[j:]
    return text

def remove_word_by_head(text, word_head = '@', split_char = ' '):
    '''
        去除文本中以某一字符开头的词
        ===============
        arguments:
            text: 要处理的文本字符串
            word_head = '@': 要去除的词的头字符，默认为 '@'
            split_char = ' ': 文本词与词之间的分隔符，可理解为去除词操作的 stop 位置，默认为 ' '
    '''
    for i in range(len(text)):
        while text[i: i + 1] == word_head:
            j = i + 1
            while text[j: j + 1] != split_char and j < len(text):
                j = j + 1
            text = text[: i] + text[j + 1:]
    return text

def remove_at(text):
    '''
        去除文本中的'回复@...:'、'//@...:'、'@...'
        ===============
        arguments:
            text: 要处理的文本字符串
    '''
    for i in range(len(text)):
        while text[i: i + 3] == '回复@' or text[i: i + 3] == '//@':
            j = i + 3
            while text[j: j + 1] != ':' and j < len(text):
                j = j + 1
            text = text[: i] + text[j + 1:]
    for i in range(len(text)):
        while text[i: i + 1] == '@':
            j = i + 1
            while text[j: j + 1] != ' ' and j < len(text):
                j = j + 1
            text = text[: i] + text[j + 1:]
    return text

def short_text_none(text, max_length = 5):
    '''
        将短文本变成None
        ===============
        arguments:
            text: 要处理的文本字符串
            max_length = 5: 去除短文本的最大长度
        ===============
        example:
            #去除 pandas.DataFrame 中的短文本
            data = data.apply(short_text_none)
            data = data.dropna()
    '''
    if len(text) <= max_length:
        return None
    else:
        return text

def get_stopwords(filename):
    '''
        获取文件中的停用词
        文件中停用词应以 \n 分割
        ===============
        arguments:
            filename: 文件名
        ===============
        example:
            get_stopwords('stopwords.txt')
    '''
    with open(filename, encoding = 'utf8') as fp:
        stopwords = fp.read()
    stopwords = stopwords.split('\n')
    return stopwords

def cut_jieba(text):
    '''
        jieba分词，以空格相连
        ===============
        import jieba
        ===============
        arguments:
            text: 文本字符串
        ===============
        example:
            #pandas.DataFrame
            data['jieba'] = data['text'].apply(cut_jieba)
    '''
    return ' '.join(jieba.cut(text))
