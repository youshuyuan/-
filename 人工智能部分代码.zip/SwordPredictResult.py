#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import joblib
import pickle
import jieba
from jieba.analyse import *
from SwordTextPreprocessing import *
from sklearn.feature_extraction.text import CountVectorizer

def test_preprecessing_predict(test_filename, column_name, predict_filename, countvectorizer_filename, model_filename):
    '''
        封装的预测测试（单一测试，通过文件名，输出预测文件）
        ===============
        import pandas as pd
        import joblib
        import pickle
        import jieba
        from SwordTextPreprocessing import *
        from sklearn.feature_extraction.text import CountVectorizer
        ===============
        arguments:
            test_filename: 测试数据文件名
            column_name: 测试数据的列名
            predict_filename: 预测结果输出文件名
            countvectorizer_filename: 词向量模型（sklearn.feature_extraction.text.CountVectorizer）文件名
            model_filename: 预测所用模型文件名
    '''
    #从文件中调出模型、测试数据
    word_vector = CountVectorizer(vocabulary = pickle.load(open(countvectorizer_filename, "rb")))
    model = joblib.load(model_filename)
    test_data = pd.read_csv(test_filename)
    test_data = pd.DataFrame(test_data[column_name], columns = [column_name])
    #压缩、去除 @ 、去除短句
    test_data[column_name] = test_data[column_name].apply(text_compress_save2)
    test_data[column_name] = test_data[column_name].apply(remove_at)
    test_data[column_name] = test_data[column_name].apply(short_text_none)
    test_data = test_data.dropna(how = 'any')
    #分词
    test_data['jieba'] = test_data[column_name].apply(cut_jieba)
    #转词向量
    X_test_vector = word_vector.transform(test_data['jieba'])
    # 执行算法预测
    test_data = test_data.drop('jieba', axis = 1)
    test_data['predict'] = model.predict(X_test_vector)
    #预测结果输出到文件
    test_data.to_csv(predict_filename, index = False)

def emotion_predict(data, column_name, countvectorizer_filename, model_filename):
    '''
        情感预测
        0：消极，1：中立，2：积极，-1：无关
        ===============
        import pandas as pd
        import joblib
        import pickle
        import jieba
        from SwordTextPreprocessing import *
        from sklearn.feature_extraction.text import CountVectorizer
        ===============
        arguments:
            data: DataFrame 要预测的文本数据
            column_name: 要预测文本数据的列名
            countvectorizer_filename: 词向量模型（sklearn.feature_extraction.text.CountVectorizer）文件名
            model_filename: 预测所用模型文件名
        ===============
        return:
            predict_result: DataFrame 预测结果，有两列：
                一列为筛除掉短句后的文本内容，列名为参数 column_name
                一列为预测的情感结果，列名为 predict
    '''
    #从文件中调出模型
    word_vector = CountVectorizer(vocabulary = pickle.load(open(countvectorizer_filename, "rb")))
    model = joblib.load(model_filename)
    #切片保留待预测文本列
    #data = pd.DataFrame(data[column_name], columns = [column_name])
    columns = [column_name, 'user_id']
    data = pd.DataFrame(data, columns = columns)
    #压缩、去除 @ 、去除短句
    data[column_name] = data[column_name].apply(text_compress_save2)
    data[column_name] = data[column_name].apply(remove_at)
    data[column_name] = data[column_name].apply(short_text_none)
    data = data.dropna(how = 'any')
    #分词
    data['jieba'] = data[column_name].apply(cut_jieba)
    #转词向量
    X_test_vector = word_vector.transform(data['jieba'])
    #去掉分词列
    data = data.drop('jieba', axis = 1)
    #执行算法预测
    data['predict'] = model.predict(X_test_vector)
    return data

def text_sort(data, column_name, countvectorizer_filename, model_filename):
    '''
        文本分类（批量）
        ===============
        import pandas as pd
        import joblib
        import pickle
        import jieba
        from SwordTextPreprocessing import *
        from sklearn.feature_extraction.text import CountVectorizer
        ===============
        arguments:
            data: DataFrame 要预测的文本数据
            column_name: 要预测文本数据的列名
            countvectorizer_filename: 词向量模型（sklearn.feature_extraction.text.CountVectorizer）文件名
            model_filename: 预测所用模型文件名
        ===============
        return:
            predict_result: 文本种类
    '''
    #从文件中调出模型
    word_vector = CountVectorizer(vocabulary = pickle.load(open(countvectorizer_filename, "rb")))
    model = joblib.load(model_filename)
    #切片保留待预测文本列
    #data = pd.DataFrame(data[column_name], columns = [column_name])
    #分词
    data['jieba'] = data[column_name].apply(cut_jieba)
    #转词向量
    X_test_vector = word_vector.transform(data['jieba'])
    #去掉分词列
    data = data.drop('jieba', axis = 1)
    #执行算法预测
    data['predict'] = model.predict(X_test_vector)
    return data

def text_sort_one(text, countvectorizer_filename, model_filename):
    '''
        文本分类
        ===============
        import pandas as pd
        import joblib
        import pickle
        import jieba
        from SwordTextPreprocessing import *
        from sklearn.feature_extraction.text import CountVectorizer
        ===============
        arguments:
            text: 文本
            countvectorizer_filename: 词向量模型（sklearn.feature_extraction.text.CountVectorizer）文件名
            model_filename: 预测所用模型文件名
        ===============
        return:
            predict_result: 文本种类
    '''
    #从文件中调出模型
    word_vector = CountVectorizer(vocabulary = pickle.load(open(countvectorizer_filename, "rb")))
    model = joblib.load(model_filename)
    #分词
    text = cut_jieba(text)
    #转词向量
    X_test_vector = word_vector.transform([text])
    #执行算法预测
    predict_result = model.predict(X_test_vector)
    return predict_result[0]

def textrank_keyword(data, min_count = 2):
    '''
        TextRank 提取关键词 + 各类别词频统计
        ===============
        import pandas as pd
        from jieba.analyse import *
        ===============
        arguments:
            data: 预测结果数据，DataFrame 类型
            min_count = 2: 保留的最小关键词出现次数，出现次数小于此数的关键词将被舍去
        ===============
        return:
            keyword_df_dict: 四种预测结果（0 消极，1 中立，2 积极，-1 无关）和其关键字及出现次数 DataFrame 的键值对
            （注意：有时某一种可能没有，即可能出现如 keyword_df_dict[-1] 不存在的情况）
    '''
    #用于保存各类别关键词
    keyword_list0, keyword_list1, keyword_list2, keyword_list3 = [], [], [], []
    keyword_dict = {0: keyword_list0, 1: keyword_list1, 2: keyword_list2, -1: keyword_list3}
    keyword_df_dict = {}
    #逐行进行关键词提取
    for index, row in data.iterrows():
        text = row['text']
        keywords = textrank(text, topK = 3)
        for keyword in keywords:
            #根据情感预测选用各类情感的列表存储
            keyword_dict.get(row['predict']).append({'keyword': keyword, 'count': 1})
    #统计各类别关键词
    for i in range(-1, 3):
        if keyword_dict[i] != []:
            keyword_data = pd.DataFrame(keyword_dict[i])
            #加和各词的次数
            keyword_result = keyword_data.groupby('keyword')['count'].sum().rename('count').reset_index()
            keyword_result = keyword_result[keyword_result['count'] >= min_count]
            #按照次数降序排序
            keyword_result.sort_values('count', inplace = True, ascending = False)
            #重置索引（非必需）
            keyword_result = keyword_result.reset_index(drop=True)
            #加入要返回的词典
            keyword_df_dict[i] = keyword_result
    return keyword_df_dict

def tf_idf_keyword(data, min_count = 2):
    '''
        TF-IDF 提取关键词 + 各类别词频统计
        ===============
        import pandas as pd
        from jieba.analyse import *
        ===============
        arguments:
            data: 预测结果数据，DataFrame 类型
            min_count = 2: 保留的最小关键词出现次数，出现次数小于此数的关键词将被舍去
        ===============
        return:
            keyword_df_dict: 四种预测结果（0 消极，1 中立，2 积极，-1 无关）和其关键字及出现次数 DataFrame 的键值对
            （注意：有时某一种可能没有，即可能出现如 keyword_df_dict[-1] 不存在的情况）
    '''
    #用于保存各类别关键词
    keyword_list0, keyword_list1, keyword_list2, keyword_list3 = [], [], [], []
    keyword_dict = {0: keyword_list0, 1: keyword_list1, 2: keyword_list2, -1: keyword_list3}
    keyword_df_dict = {}
    #逐行进行关键词提取
    for index, row in data.iterrows():
        text = row['text']
        keywords = extract_tags(text, topK = 3)
        for keyword in keywords:
            #根据情感预测选用各类情感的列表存储
            keyword_dict.get(row['predict']).append({'keyword': keyword, 'count': 1})
    #统计各类别关键词
    for i in range(-1, 3):
        if keyword_dict[i] != []:
            keyword_data = pd.DataFrame(keyword_dict[i])
            #加和各词的次数
            keyword_result = keyword_data.groupby('keyword')['count'].sum().rename('count').reset_index()
            keyword_result = keyword_result[keyword_result['count'] >= min_count]
            #按照次数降序排序
            keyword_result.sort_values('count', inplace = True, ascending = False)
            #重置索引（非必需）
            keyword_result = keyword_result.reset_index(drop=True)
            #加入要返回的词典
            keyword_df_dict[i] = keyword_result
    return keyword_df_dict

def remove_0and2(keyword_df_dict):
    '''
        0类，2类 去除 0 和 2 的交集 （即去除无感情色彩的关键词）
        （注意：0 和 2 某一类数据很少时（如正能量和争议性话题）请慎用，可能完全抹去，或者考虑修改提取关键词方法的 min_count ）
        ===============
        import pandas as pd
        ===============
        arguments:
            keyword_df_dict: 提取关键词方法的返回值
        ===============
        example:
            dict1 = textrank_keyword(data)
            remove_0and2(dict1)
    '''
    if 0 in keyword_df_dict and 2 in keyword_df_dict:
        df0 = keyword_df_dict[0]
        df2 = keyword_df_dict[2]
        keyword_df_dict[0] = df_difference(df0, df2, 'keyword')
        keyword_df_dict[2] = df_difference(df2, df0, 'keyword')

def df_difference(df1, df2, columns):
    '''
        df1 - df2 (DataFrame 的差集)
        ===============
        import pandas as pd
        ===============
        arguments:
            df1: DataFrame
            df2: DataFrame
            columns: 做差集依据的列名（一列可用列名、多列使用列表）
        ===============
        return:
            df1 - df2
            （注意：df1 自身的重复行也将被删除）
    '''
    df1 = df1.append(df2)
    df1 = df1.append(df2)
    df1.drop_duplicates(subset = columns, keep = False, inplace = True)
    return df1

def text_cut_by_emotion(data):
    '''
        不同情感文本列表
        可通过列表长度得到各类评论数
        ===============
        import pandas as pd
        ===============
        arguments:
            data: DataFrame 预测结果
        ===============
        return:
            text_dict: 四种预测结果（0 消极，1 中立，2 积极，-1 无关）和其文本列表的键值对
    '''
    text_list0, text_list1, text_list2, text_list3 = [], [], [], []
    text_dict = {0: text_list0, 1: text_list1, 2: text_list2, -1: text_list3}
    for index, row in data.iterrows():
        text_dict.get(row['predict']).append(row['text'])
    return text_dict

def get_emotion_proportion(data):
    '''
        不同情感文本占比
        ===============
        import pandas as pd
        ===============
        arguments:
            data: DataFrame 预测结果
        ===============
        return:
            proportion_dict: 四种预测结果（0 消极，1 中立，2 积极，-1 无关）和其占比的键值对
    '''
    count_all = len(data)
    count0 = len(data[data['predict'] == 0])
    count1 = len(data[data['predict'] == 1])
    count2 = len(data[data['predict'] == 2])
    count3 = len(data[data['predict'] == -1])
    proportion0 = count0 / count_all
    proportion1 = count1 / count_all
    proportion2 = count2 / count_all
    proportion3 = count3 / count_all
    return {0: proportion0, 1: proportion1, 2: proportion2, -1: proportion3}

def get_emotion_count(data):
    '''
        不同情感文本数量
        ===============
        import pandas as pd
        ===============
        arguments:
            data: DataFrame 预测结果
        ===============
        return:
            proportion_dict: 四种预测结果（0 消极，1 中立，2 积极，-1 无关）和其数量的键值对
    '''
    count0 = len(data[data['predict'] == 0])
    count1 = len(data[data['predict'] == 1])
    count2 = len(data[data['predict'] == 2])
    count3 = len(data[data['predict'] == -1])
    return {0: count0, 1: count1, 2: count2, -1: count3}