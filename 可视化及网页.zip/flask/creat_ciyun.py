import shutil
import os
from pyecharts.globals import CurrentConfig
from random import randrange
from flask import Flask, render_template
from pyecharts import options as opts
import random
from pyecharts.charts import Geo,Bar,Map,Line,Timeline,Page, WordCloud,Pie
from pyecharts.globals import ChartType, SymbolType
import pandas as pd
import numpy as np
import pymysql
from pyecharts.globals import ThemeType
import time
from pyecharts.render import make_snapshot
from snapshot_selenium import snapshot
connect=pymysql.connect("112.124.15.73","user1","user1","weibo")
cursor = connect.cursor()

def get_ciyun(label,n) -> WordCloud:
    sql="select keywordpos from wb_title where  title='%s'" %(label)
    cursor.execute(sql)
    res = cursor.fetchone()
    words=[(k,v)for k,v in eval(res[0]).items()]
    c = (
        WordCloud()
        .add("", words, word_size_range=[20, 100], shape='cardioid')
        .set_global_opts(title_opts=opts.TitleOpts(title=label,subtitle="消极"))
    )
    make_snapshot(snapshot, c.render(), str(n)+".png")
    shutil.move("G:/实训/代码/"+str(n)+".png", "G:/实训/代码/flask/templates/photo/"+str(n)+".png")
    return c

def get_ciyun_fan(label,n) -> WordCloud:
    sql="select keywordneg from wb_title where  title='%s'" %(label)
    cursor.execute(sql)
    res = cursor.fetchone()
    words=[(k,v)for k,v in eval(res[0]).items()]
    c = (
        WordCloud()
        .add("", words, word_size_range=[20, 100], shape='cardioid')
        .set_global_opts(title_opts=opts.TitleOpts(title=label,subtitle="消极"))
    )
    make_snapshot(snapshot, c.render(), str(n)+".png")
    shutil.move("G:/实训/代码/"+str(n)+".png", "G:/实训/代码/flask/templates/photo_fan/"+str(n)+".png")
    return c

def get_label(label):
    selectsql ="select title from wb_title where label='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchone()
    data=[]
    while res:
        data.extend(list(res))
        res = cursor.fetchone()
    data.reverse()
    return data

for i in range(4,4+len(get_label("时政"))):
    get_ciyun(get_label("时政")[i-4],i)
    get_ciyun_fan(get_label("时政")[i-4],i)
for i in range(9,9+len(get_label("体育"))):
    get_ciyun(get_label("体育")[i-9],i)
    get_ciyun_fan(get_label("体育")[i-9],i)
for i in range(14,14+len(get_label("时政"))):
    get_ciyun(get_label("娱乐")[i-14],i)
    get_ciyun_fan(get_label("娱乐")[i-14],i)