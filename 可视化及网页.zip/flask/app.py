import shutil
import os
from pyecharts.globals import CurrentConfig
from random import randrange
from flask import Flask, render_template
from pyecharts import options as opts
import random
from pyecharts.charts import Geo,Bar,Map,Line,Timeline,Page, WordCloud,Pie
from pyecharts.globals import ChartType, SymbolType
import pandas as pd
import numpy as np
import pymysql
from pyecharts.globals import ThemeType
import time
from pyecharts.render import make_snapshot
from snapshot_selenium import snapshot

connect=pymysql.connect("112.124.15.73","user1","user1","weibo")
cursor = connect.cursor()

#获取热点话题名称
def get_label(label):
    selectsql ="select title from wb_title where label='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchone()
    data=[]
    while res:
        data.extend(list(res))
        res = cursor.fetchone()
    data.reverse()
    return data

#绘制饼图
def pie_base(label) ->Pie:
    sql="select proportion from wb_title where  title='%s'" %(label)
    cursor.execute(sql)
    res = cursor.fetchone()
    biao=["消极","中立","积极","无关"]
    data=list(eval(res[0]).values())
    c=(
        Pie()
        .add("",[list(z) for z in zip(biao,data)])
        .set_global_opts(title_opts=opts.TitleOpts(title="热点问题关注度",subtitle=label))

    )
    return c

#获取大类例如：时政等的关注度时间列表
def get_time(label):
    selectsql ="select time from wb_timeCount_all_new where wbclass='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchone()
    data=[]
    while res:
        data.extend(list(res))
        res = cursor.fetchone()
    data.reverse()
    return data

#获取大类例如：时政等的关注度对应时间的数量列表
def get_count(label):
    selectsql ="select count from wb_timeCount_all_new where wbclass='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchone()
    data=[]
    while res:
        data.extend(list(res))
        res = cursor.fetchone()
    data.reverse()
    return data

#获取大类例如：时政等的关注度省份分布
def get_provence(label):
    dict_pro={}
    data = []
    selectsql ="select pname,count from wb_locationCount_all where wbclass='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchall()
    for i in res:
        tupleTolist = list(i)
        dict_pro[tupleTolist[0]] = int(tupleTolist[1])
    data = [[n, v] for n, v in dict_pro.items()]
    b=np.array(data).tolist() 
    return data

##获取具体话题的关注度时间列表
def get_time2(label):
    selectsql ="select time from wb_timeCount where title='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchone()
    data=[]
    while res:
        data.extend(list(res))
        res = cursor.fetchone()
    data.reverse()
    return data

#获取具体话题的关注度对应时间的数量列表
def get_count2(label):
    selectsql ="select count from wb_timeCount where title='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchone()
    data=[]
    while res:
        data.extend(list(res))
        res = cursor.fetchone()
    data.reverse()
    return data

#获取具体话题的关注度省份分布
def get_provence2(label):
    dict_pro={}
    data = []
    selectsql ="select pname,count from wb_locationCount where title='%s'" %(label)
    cursor.execute(selectsql)
    res = cursor.fetchall()
    for i in res:
        tupleTolist = list(i)
        dict_pro[tupleTolist[0]] = int(tupleTolist[1])
    data = [[n, v] for n, v in dict_pro.items()]
    b=np.array(data).tolist() 
    return data
    
app = Flask(__name__, static_folder="templates")

#绘制折线图
def line_base(time,count,label)->Line:
    line = Line(init_opts=opts.InitOpts(theme=ThemeType.ESSOS))
    line.add_xaxis(time)
    line.add_yaxis('关注度',count)
    line.set_global_opts(title_opts=opts.TitleOpts(title="热点问题关注度",subtitle=label))
    return line

#绘制柱状图
def bar_base(time,count,label,line)->Bar:
    counts=[]
    g1=Bar(init_opts=opts.InitOpts(theme=ThemeType.DARK))
    g1.add_xaxis(time)
    for i in count:
        counts.append(i/2)
    g1.add_yaxis('关注度',counts)
    g1.set_global_opts(title_opts=opts.TitleOpts(title="热点问题关注度",subtitle=label))
    g1.set_series_opts(label_opts=opts.LabelOpts(is_show=False))
    g1.overlap(line)
    return g1

#绘制地理热度图
def geo_base(data,label) -> Geo:
    b=[]
    for a in range(0,len(data)):
        b.append(data[a][1])
    geo = Geo()
    geo.add_schema(maptype="china")
    geo.add("关注度", data, type_=ChartType.HEATMAP,point_size=20,blur_size=30)
    geo.set_global_opts(visualmap_opts=opts.VisualMapOpts(max_=max(b)),title_opts=opts.TitleOpts(title=label))
    return geo

#绘制地理分布图
def map_base(data,label) -> Map:
    b=[]
    for a in range(0,len(data)):
        b.append(data[a][1])
    map = (
    Map()
    .add("关注度", data, "china")
    .set_global_opts(title_opts=opts.TitleOpts(title=label),
    visualmap_opts=opts.VisualMapOpts(max_=max(b)))
    )
    return map

#绘制时间序列图
def timeline_base(line1,line2,line3)->Timeline:
    timeline = Timeline(init_opts=opts.InitOpts(theme=ThemeType.PURPLE_PASSION)) 
    timeline.add(line1, '今日') 
    timeline.add(line2, '三天') 
    timeline.add(line3, '五天') 
    return timeline

#代入相关数据绘制大类的时间序列图
def draw(label):
    a1=get_time(label)[0:24]
    a1.reverse()
    b1=get_count(label)[0:24]
    b1.reverse()
    c1 = line_base(a1,b1,label)
    g1= bar_base(a1,b1,label,c1)
    a2=get_time(label)[0:72]
    a2.reverse()
    b2=get_count(label)[0:72]
    b2.reverse()
    c2 = line_base(a2,b2,label)
    g2= bar_base(a2,b2,label,c2)
    a3=get_time(label)[0:120]
    a3.reverse()
    b3=get_count(label)[0:120]
    b3.reverse()
    c3 = line_base(a3,b3,label)
    g3= bar_base(a3,b3,label,c3)
    return timeline_base(g1,g2,g3)

#代入相关数据绘制具体话题的时间序列图
def draw2(label):
    a1=get_time2(label)[0:24]
    a1.reverse()
    b1=get_count2(label)[0:24]
    b1.reverse()
    c1 = line_base(a1,b1,label)
    g1= bar_base(a1,b1,label,c1)
    a2=get_time2(label)[0:72]
    a2.reverse()
    b2=get_count2(label)[0:72]
    b2.reverse()
    c2 = line_base(a2,b2,label)
    g2= bar_base(a2,b2,label,c2)
    a3=get_time2(label)[0:120]
    a3.reverse()
    b3=get_count2(label)[0:120]
    b3.reverse()
    c3 = line_base(a3,b3,label)
    g3= bar_base(a3,b3,label,c3)
    return timeline_base(g1,g2,g3)

@app.route("/")
def index():
    shizheng=get_label("时政")[0:5]
    tiyu=get_label("体育")
    yule=get_label("娱乐")
    return render_template("index.html",shizheng=shizheng,tiyu=tiyu,yule=yule)

@app.route("/pie-shizheng1")
def get_pie_shizheng1():
    g=pie_base(get_label("时政")[0])
    return g.dump_options_with_quotes()

@app.route("/pie-shizheng2")
def get_pie_shizheng2():
    g=pie_base(get_label("时政")[1])
    return g.dump_options_with_quotes()
    
@app.route("/pie-shizheng3")
def get_pie_shizheng3():
    g=pie_base(get_label("时政")[2])
    return g.dump_options_with_quotes()

@app.route("/pie-shizheng4")
def get_pie_shizheng4():
    g=pie_base(get_label("时政")[3])
    return g.dump_options_with_quotes()

@app.route("/pie-shizheng5")
def get_pie_shizheng5():
    g=pie_base(get_label("时政")[4])
    return g.dump_options_with_quotes()

@app.route("/pie-tiyu1")
def get_pie_tiyu1():
    g=pie_base(get_label("体育")[0])
    return g.dump_options_with_quotes()

@app.route("/pie-tiyu2")
def get_pie_tiyu2():
    g=pie_base(get_label("体育")[1])
    return g.dump_options_with_quotes()
    
@app.route("/pie-tiyu3")
def get_pie_tiyu3():
    g=pie_base(get_label("体育")[2])
    return g.dump_options_with_quotes()

@app.route("/pie-tiyu4")
def get_pie_tiyu4():
    g=pie_base(get_label("体育")[3])
    return g.dump_options_with_quotes()
    
@app.route("/pie-tiyu5")
def get_pie_tiyu5():
    g=pie_base(get_label("体育")[4])
    return g.dump_options_with_quotes()

@app.route("/pie-yule1")
def get_pie_yule1():
    g=pie_base(get_label("娱乐")[0])
    return g.dump_options_with_quotes()

@app.route("/pie-yule2")
def get_pie_yule2():
    g=pie_base(get_label("娱乐")[1])
    return g.dump_options_with_quotes()
    
@app.route("/pie-yule3")
def get_pie_yule3():
    g=pie_base(get_label("娱乐")[2])
    return g.dump_options_with_quotes()

@app.route("/pie-yule4")
def get_pie_yule4():
    g=pie_base(get_label("娱乐")[3])
    return g.dump_options_with_quotes()
    
@app.route("/pie-yule5")
def get_pie_yule5():
    g=pie_base(get_label("娱乐")[4])
    return g.dump_options_with_quotes()

@app.route("/lineChart-shizheng")
def get_line_chart_shizheng():
    g=draw("时政")
    return g.dump_options_with_quotes()

@app.route("/lineChart-shizheng1")
def get_line_chart_shizheng1():
    g=draw2(get_label("时政")[0])
    return g.dump_options_with_quotes()

@app.route("/lineChart-shizheng2")
def get_line_chart_shizheng2():
    g=draw2(get_label("时政")[1])
    return g.dump_options_with_quotes()

@app.route("/lineChart-shizheng3")
def get_line_chart_shizheng3():
    g=draw2(get_label("时政")[2])
    return g.dump_options_with_quotes()

@app.route("/lineChart-shizheng4")
def get_line_chart_shizheng4():
    g=draw2(get_label("时政")[3])
    return g.dump_options_with_quotes()

@app.route("/lineChart-shizheng5")
def get_line_chart_shizheng5():
    g=draw2(get_label("时政")[4])
    return g.dump_options_with_quotes()

@app.route("/lineChart-yule")
def get_line_chart_yule():
    g=draw("娱乐")
    return g.dump_options_with_quotes()

@app.route("/lineChart-yule1")
def get_line_chart_yule1():
    g=draw2(get_label("娱乐")[0])
    return g.dump_options_with_quotes()

@app.route("/lineChart-yule2")
def get_line_chart_yule2():
    g=draw2(get_label("娱乐")[1])
    return g.dump_options_with_quotes()

@app.route("/lineChart-yule3")
def get_line_chart_yule3():
    g=draw2(get_label("娱乐")[2])
    return g.dump_options_with_quotes()

@app.route("/lineChart-yule4")
def get_line_chart_yule4():
    g=draw2(get_label("娱乐")[3])
    return g.dump_options_with_quotes()

@app.route("/lineChart-yule5")
def get_line_chart_yule5():
    g=draw2(get_label("娱乐")[4])
    return g.dump_options_with_quotes()

@app.route("/lineChart-tiyu")
def get_line_chart_tiyu():
    g=draw("体育")
    return g.dump_options_with_quotes()


@app.route("/lineChart-tiyu1")
def get_line_chart_tiyu1():
    g=draw2(get_label("体育")[0])
    return g.dump_options_with_quotes()


@app.route("/lineChart-tiyu2")
def get_line_chart_tiyu2():
    g=draw2(get_label("体育")[1])
    return g.dump_options_with_quotes()

@app.route("/lineChart-tiyu3")
def get_line_chart_tiyu3():
    g=draw2(get_label("体育")[2])
    return g.dump_options_with_quotes()

@app.route("/lineChart-tiyu4")
def get_line_chart_tiyu4():
    g=draw2(get_label("体育")[3])
    return g.dump_options_with_quotes()

@app.route("/lineChart-tiyu5")
def get_line_chart_tiyu5():
    g=draw2(get_label("体育")[4])
    return g.dump_options_with_quotes()

@app.route("/geoChart-shizheng")
def get_geo_chart_shizheng():
    c = geo_base(get_provence("时政"),"时政")
    return c.dump_options_with_quotes()

@app.route("/geoChart-shizheng1")
def get_geo_chart_shizheng1():
    c = geo_base(get_provence2(get_label("时政")[0]),get_label("时政")[0])
    return c.dump_options_with_quotes()

@app.route("/geoChart-shizheng2")
def get_geo_chart_shizheng2():
    c = geo_base(get_provence2(get_label("时政")[1]),get_label("时政")[1])
    return c.dump_options_with_quotes()

@app.route("/geoChart-shizheng3")
def get_geo_chart_shizheng3():
    c = geo_base(get_provence2(get_label("时政")[2]),get_label("时政")[2])
    return c.dump_options_with_quotes()

@app.route("/geoChart-shizheng4")
def get_geo_chart_shizheng4():
    c = geo_base(get_provence2(get_label("时政")[3]),get_label("时政")[3])
    return c.dump_options_with_quotes()

@app.route("/geoChart-shizheng5")
def get_geo_chart_shizheng5():
    c = geo_base(get_provence2(get_label("时政")[4]),get_label("时政")[4])
    return c.dump_options_with_quotes()

@app.route("/geoChart-tiyu")
def get_geo_chart_tiyu():
    c = geo_base(get_provence("体育"),"体育")
    return c.dump_options_with_quotes()

@app.route("/geoChart-tiyu1")
def get_geo_chart_tiyu1():
    c = geo_base(get_provence2(get_label("体育")[0]),get_label("体育")[0])
    return c.dump_options_with_quotes()

@app.route("/geoChart-tiyu2")
def get_geo_chart_tiyu2():
    c = geo_base(get_provence2(get_label("体育")[1]),get_label("体育")[1])
    return c.dump_options_with_quotes()

@app.route("/geoChart-tiyu3")
def get_geo_chart_tiyu3():
    c = geo_base(get_provence2(get_label("体育")[2]),get_label("体育")[2])
    return c.dump_options_with_quotes()

@app.route("/geoChart-tiyu4")
def get_geo_chart_tiyu4():
    c = geo_base(get_provence2(get_label("体育")[3]),get_label("体育")[3])
    return c.dump_options_with_quotes()

@app.route("/geoChart-tiyu5")
def get_geo_chart_tiyu5():
    c = geo_base(get_provence2(get_label("体育")[4]),get_label("体育")[4])
    return c.dump_options_with_quotes()

@app.route("/geoChart-yule")
def get_geo_chart_yule():
    c = geo_base(get_provence("娱乐"),"娱乐")
    return c.dump_options_with_quotes()

@app.route("/geoChart-yule1")
def get_geo_chart_yule1():
    c = geo_base(get_provence2(get_label("娱乐")[0]),get_label("娱乐")[0])
    return c.dump_options_with_quotes()

@app.route("/geoChart-yule2")
def get_geo_chart_yule2():
    c = geo_base(get_provence2(get_label("娱乐")[1]),get_label("娱乐")[1])
    return c.dump_options_with_quotes()

@app.route("/geoChart-yule3")
def get_geo_chart_yule3():
    c = geo_base(get_provence2(get_label("娱乐")[2]),get_label("娱乐")[2])
    return c.dump_options_with_quotes()

@app.route("/geoChart-yule4")
def get_geo_chart_yule4():
    c = geo_base(get_provence2(get_label("娱乐")[3]),get_label("娱乐")[3])
    return c.dump_options_with_quotes()

@app.route("/geoChart-yule5")
def get_geo_chart_yule5():
    c = geo_base(get_provence2(get_label("娱乐")[4]),get_label("娱乐")[4])
    return c.dump_options_with_quotes()

@app.route("/mapChart-shizheng")
def get_map_chart_shizheng():
    c = map_base(get_provence("时政"),"时政")
    return c.dump_options_with_quotes()

@app.route("/mapChart-shizheng1")
def get_map_chart_shizheng1():
    c = map_base(get_provence2(get_label("时政")[0]),get_label("时政")[0])
    return c.dump_options_with_quotes()

@app.route("/mapChart-shizheng2")
def get_map_chart_shizheng2():
    c = map_base(get_provence2(get_label("时政")[1]),get_label("时政")[1])
    return c.dump_options_with_quotes()

@app.route("/mapChart-shizheng3")
def get_map_chart_shizheng3():
    c = map_base(get_provence2(get_label("时政")[2]),get_label("时政")[2])
    return c.dump_options_with_quotes()

@app.route("/mapChart-shizheng4")
def get_map_chart_shizheng4():
    c = map_base(get_provence2(get_label("时政")[3]),get_label("时政")[3])
    return c.dump_options_with_quotes()

@app.route("/mapChart-shizheng5")
def get_map_chart_shizheng5():
    c = map_base(get_provence2(get_label("时政")[4]),get_label("时政")[4])
    return c.dump_options_with_quotes()

@app.route("/mapChart-tiyu")
def get_map_chart_tiyu():
    c = map_base(get_provence("体育"),"体育")
    return c.dump_options_with_quotes()

@app.route("/mapChart-tiyu1")
def get_map_chart_tiyu1():
    c = map_base(get_provence2(get_label("体育")[0]),get_label("体育")[0])
    return c.dump_options_with_quotes()

@app.route("/mapChart-tiyu2")
def get_map_chart_tiyu2():
    c = map_base(get_provence2(get_label("体育")[1]),get_label("体育")[1])
    return c.dump_options_with_quotes()

@app.route("/mapChart-tiyu3")
def get_map_chart_tiyu3():
    c = map_base(get_provence2(get_label("体育")[2]),get_label("体育")[2])
    return c.dump_options_with_quotes()

@app.route("/mapChart-tiyu4")
def get_map_chart_tiyu4():
    c = map_base(get_provence2(get_label("体育")[3]),get_label("体育")[3])
    return c.dump_options_with_quotes()

@app.route("/mapChart-tiyu5")
def get_map_chart_tiyu5():
    c = map_base(get_provence2(get_label("体育")[4]),get_label("体育")[4])
    return c.dump_options_with_quotes()

@app.route("/mapChart-yule")
def get_map_chart_yule():
    c = map_base(get_provence("娱乐"),"娱乐")
    return c.dump_options_with_quotes()

@app.route("/mapChart-yule1")
def get_map_chart_yule1():
    c = map_base(get_provence2(get_label("娱乐")[0]),get_label("娱乐")[0])
    return c.dump_options_with_quotes()

@app.route("/mapChart-yule2")
def get_map_chart_yule2():
    c = map_base(get_provence2(get_label("娱乐")[1]),get_label("娱乐")[1])
    return c.dump_options_with_quotes()

@app.route("/mapChart-yule3")
def get_map_chart_yule3():
    c = map_base(get_provence2(get_label("娱乐")[2]),get_label("娱乐")[2])
    return c.dump_options_with_quotes()

@app.route("/mapChart-yule4")
def get_map_chart_yule4():
    c = map_base(get_provence2(get_label("娱乐")[3]),get_label("娱乐")[3])
    return c.dump_options_with_quotes()

@app.route("/mapChart-yule5")
def get_map_chart_yule5():
    c = map_base(get_provence2(get_label("娱乐")[4]),get_label("娱乐")[4])
    return c.dump_options_with_quotes()


if __name__ == "__main__":
    app.run()

cursor.close()
connect.close()