#!/bin/bash
access=('2.00uLrtJGs87MtBf6c9182192wbvdPE' '2.00uLrtJGMqSPwD1240d9d76cGh52_B' '2.00uLrtJGg_MYFD9ec493d2b7RTLeuC' '2.00uLrtJGGYe4NC02e766c0d7LQzGFD' '2.00uLrtJG06Kti607b08fa9a29KBwcD' '2.00uLrtJG6XFhPEba9455723f34lynB')
i=0
while true
do
{
zero=0;
i=$i%6
result=`python3 -u choose_id.py`;
if [ "$result" != "$zero" ];then
echo $result
echo ${access[i]}
python3 -u -W ignore weibo_comment.py $result ${access[i]} &
((i++))
fi
sleep 120
}
done
