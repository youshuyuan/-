import pymysql

conn = pymysql.connect(host='112.124.15.73', port=3306, user='user1', passwd='user1', db='weibo',
                       charset='utf8', connect_timeout=1000)
cursor = conn.cursor()
select_sql = "select id from wb_hot where start = '0'"
update_sql = "update wb_hot set start = '1' where id = %s"
cursor.execute(select_sql)
result = cursor.fetchone()
try:
    r = result[0]
    cursor.execute(update_sql,r)
    conn.commit()
    print(r)
except Exception:
    print(0)
cursor.close()
