"""
微博热点抓取
"""
import datetime
from pyvirtualdisplay import Display
from selenium import webdriver
import time
import pymysql
# from selenium.webdriver.support.wait import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC


def hot_spider():
    # 进行mysql连接操作
    conn = pymysql.connect(host='112.124.15.73'
                           , port=3306, user='user1', passwd='user1', db='weibo',
                           charset='utf8', connect_timeout=1000)
    # 获取游标
    cursor = conn.cursor()
    display = Display(visible=0, size=(1800, 1600))
    display.start()
    options = webdriver.FirefoxOptions()
    options.add_argument('--headless')
    select_sql = "SELECT DISTINCT title FROM wb_hot"
    cursor.execute(select_sql)
    results = cursor.fetchall()
    titles = []
    for row in results:
        titles.append(row[0])

    # driver = webdriver.Firefox(executable_path=(r'/usr/local/python3.8/bin/geckodriver'),options=options)
    driver = webdriver.Firefox(executable_path=(r'/usr/local/python3/bin/geckodriver'))
    # wait = WebDriverWait(driver, 10)
    url = "https://s.weibo.com/top/summary/"
    driver.get(url)
    time.sleep(2)
    # title = driver.find_elements_by_css_selector(" td.td-02>a")
    # # user = []
    # del title[0]

    localtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    ranks = ["置顶", "热门"]
    title = driver.find_element_by_xpath("/html/body/div[1]/div[2]/div[2]/table/tbody/tr[2]/td[2]/a")
    title_txt = title.text
    if title_txt not in titles:
        # print(i)
        title.click()
        time.sleep(5)
        all_w2 = driver.window_handles
        driver.switch_to.window(all_w2[1])
        # wait.until(EC.title_is('微博搜索'))
        insert_sql = "INSERT INTO wb_hot(title,id,time,start)" "VALUES(%s,%s,%s,%s)"
        comments = driver.find_elements_by_class_name("card-wrap")
        # print(len(comments))
        for comment in comments[1:6]:
            # comment = driver.find_element_by_xpath("/html/body/div[1]/div[3]/div[2]/div[1]/div[1]/div[" + str(j) +
            #                                        "]")
            # print(comment.get_attribute('mid'))
            try:
                rank = comment.find_element_by_class_name("card-top")
                if rank.text in ranks:
                    id = comment.get_attribute('mid')
                    on = "0"
                    data = (title_txt, id, localtime, on)
                    cursor.execute(insert_sql, data)
                    conn.commit()
            except Exception:
                break
        driver.close()
        all_w2 = driver.window_handles
        driver.switch_to.window(all_w2[0])

    driver.quit()
    conn.close()
    print(localtime + " success")


if __name__ == "__main__":
    while True:
        hot_spider()
        time.sleep(60*60*3)
