import re
import pymysql
import requests
import time
import sys
import datetime


def table_not_exists(con, table_name):
    sql = "show tables;"
    con.execute(sql)
    tables = [con.fetchall()]
    table_list = re.findall('(\'.*?\')',str(tables))
    table_list = [re.sub("'", '', each) for each in table_list]
    if table_name in table_list:
        return False
    else:
        return True


def get_json(url, page, id0, since, acc):
    params = {
        'access_token': acc,
        'count': 50,
        'page': page,
        'id': id0,
        'since_id': since
    }
    # 'access_token': '2.00uLrtJGGYe4NC02e766c0d7LQzGFD',
    # 'access_token': '2.00uLrtJGR8iH9Efb07b4fd68w7z_GB',
    c = requests.get(url=url, params=params).json()
    return c


def collect(w_id, s_id, access_id):
    conn = pymysql.connect(host='112.124.15.73'
                           , port=3306, user='user1', passwd='user1', db='weibo',
                           charset='utf8', connect_timeout=1000)
    cursor = conn.cursor()
    # table = "wb_" + str(w_id)
    # if table_not_exists(cursor, table):
    #     sql_create = "create table " + table + "(id bigint not null,time varchar(35) null,text text null,user_id " \
    #                                            "bigint null,constraint " + table + "_pk primary key (id)," \
    #                                            "constraint " + table + "_wb_users_id_fk foreign key (user_id) " \
    #                                            "references wb_users (id));"
    #     cursor.execute(sql_create)

    sql_stmt_comment = "insert ignore into wb_comment(id,time,text,user_idprovince) values(%s,%s,%s,%s,%s)"
    # sql_stmt_user = "insert ignore into wb_users(id,name,province,city,location,url,gender,followers_count," \
    #                 "friends_count,statuses_count,favourites_count,created_at) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s," \
    #                 "%s,%s)"
    since = 0
    try:
        URL = "https://api.weibo.com/2/comments/show.json"
        for k in range(1, 5):
            # print(k)
            # 'access_token': '2.00uLrtJGR8iH9Efb07b4fd68w7z_GB',
            c = get_json(URL, k, w_id, s_id, access_id)
            comment = c['comments']  # get the latest public Weibo
            length = len(comment)
            if length == 0:
                break
            if k == 1:
                since = comment[0]['id']
            for i in range(0, length):
                id = comment[i]['id']
                created_time = comment[i]['created_at']
                text = comment[i]['text']
                # source = comment[i]['source']
                user_id = comment[i]['user']['id']
                # user_name = comment[i]['user']['screen_name']
                user_province = comment[i]['user']['province']
                # user_city = comment[i]['user']['city']
                # user_location = comment[i]['user']['location']
                # user_url = comment[i]['user']['profile_url']
                # user_gender = comment[i]['user']['gender']
                # user_followers_count = comment[i]['user']['followers_count']
                # user_friends_count = comment[i]['user']['friends_count']
                # user_statuses_count = comment[i]['user']['statuses_count']
                # user_favourites_count = comment[i]['user']['favourites_count']
                # user_created_at = comment[i]['user']['created_at']

                # cursor.execute(sql_stmt_user, (user_id, user_name, user_province, user_city, user_location, user_url,
                #                                user_gender, user_followers_count, user_friends_count,
                #                                user_statuses_count, user_favourites_count, user_created_at))
                cursor.execute(sql_stmt_comment, (id, created_time, text, user_id, user_province))
                # cud操作事务必须提交
                conn.commit()
            time.sleep(2)
        print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' success ' + w_id + access_id)
        conn.close()
        return since
    except Exception as e:
        print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' error ' + str(e) + w_id + access_id )
        conn.close()
        return since


if __name__ == '__main__':
    # wid = 4509600579827820
    wid = sys.argv[1]
    access = sys.argv[2]
    since_id = 0
    for m in range(0, 3*24):
        since_id = collect(wid, since_id, access)
        # print(since_id)
        time.sleep(60*60)
