#! /bin/bash
python3 -W ignore -u weibo_hot.py
